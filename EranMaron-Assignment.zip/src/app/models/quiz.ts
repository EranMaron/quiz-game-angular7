export class Quiz {
    question: string;
    correct_answer: string;
    incorrect_answers: [];
}